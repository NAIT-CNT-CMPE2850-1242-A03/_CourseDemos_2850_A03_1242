from request_functions import get_term_data
from statistics import mean

def tups_to_dict (tups):
    ret = {}
    for x in tups:
        if not x[0] in ret.keys():
            ret[x[0]] = []
        ret[x[0]].append (int(x[1]))
    return ret

if __name__ == '__main__':

    if True :

        # question 1
        '''
        Use the get_term_data function to return information for term 1221.
        Create a dictionary from the response keyed by a tuple of user id and last name, valued by a list of strings.
        The list of strings will be the icas and grade for that ica for that user.
        The form of the elements will be 'Ica01 : 38' (see output below).
        Filter to only include ICAs, and only include failing grades.
        Order the data by last name, and summarize the output to only show students that failed more than 9 ICAs.
        '''

        res = get_term_data('1221')
        if not res is None:
            dic = {}
            for row in res:
                # create a dictionary keyed by (suid, last_name),
                # valued by all items with ica (case-insensitive) in the row
                prop_key = (row['suid'], row['last_name'])
                if not prop_key in dic.keys():  # key not there, add it
                    dic[prop_key] = []
                # use comp to filter just 'ica' and failing grade, project as desired string, assign as list
                dic[prop_key] = [f'{x} : {row[x]}' for x in row if 'ica' in str(x).lower() and int(row[x]) < 50]

            # sort the dictionary by last name in tuple from key, project back as dictionary
            dic = dict (sorted (dic.items(), key = lambda x : x[0][1]))

            # output results, filtering on more than 9 bad grades
            for key in dic.keys():
                if len(dic[key]) > 9:
                    print (key, dic[key])

        # question 2
        '''
        Use the get_term_data function to return information for term 1221.
        Build a dictionary keyed by job, valued by a list of last names with that job.
        Show the dictionary.
        Bonus: order the dictionary by descending number of people in each job (no need to put back as dictionary)
        Bonus: only show the ordered output for jobs with more than two people (no need to put back as dictionary)
        '''
        res = get_term_data('1221')
        if not res is None:
            dic = {}    # empty dic to hold results
            for row in res:
                if not row['job'] in dic.keys(): # no job as key?
                    dic[row['job']] = [] # add empty list of names
                # insert last name with this job to end of names list
                dic[row['job']].insert (-1, row['last_name'])

            # sort descending, count of people per category
            sort_res = sorted (dic.items(), key = lambda x : len(x[1]), reverse=True)

            # show results, filtered by more than two people in a job
            for x in sort_res:
                if len(x[1]) > 2:
                    print (x)

        # question 3
        '''
        Use the get_term_data function to return information for term 1221.
        Build a list of tuples, where the elements are (grade item name, grade) for all grade items for all students.
        The grade item name will be lower-case. Grade items will be defined as 'ica', 'lab', or 'exam' in the field name.
        Create separate lists from this master list for icas, labs, and exams.
        Create a function called tups_to_dict that will accept any of these lists,
         and turn it into a dictionary keyed by activity name,
         and valued by a list of the grades (as ints) for that activity.
        From these dictionaries, show the average (mean) score for each ICA, the min grade for each lab, and the max score for each exam.
        '''

        res = get_term_data('1221')
        if not res is None:
            data = [] # empty list to hold results
            for row in res:
                # filter with comp to find only icas, labs, and exams (case-insensitive), project to tuple
                row_res = ([(str(x).lower(), row[x]) for x in row if 'ica' in str(x).lower() or 'lab' in str(x).lower() or 'exam' in str(x).lower()])
                # add collection to the growing results
                for x in row_res:
                    data.append(x)

            # pull out individual work types
            icas = [x for x in data if 'ica' in x[0]]
            labs = [x for x in data if 'lab' in x[0]]
            exams = [x for x in data if 'exam' in x[0]]

            # use support function to flip to dictionary
            dic_ica = tups_to_dict (icas)
            dic_labs = tups_to_dict(labs)
            dic_exams = tups_to_dict(exams)

            # show desired stats (but data is bad, so this is not very exciting...)
            for x in dic_ica.keys():
                print (x, round (mean(dic_ica[x]), 1))
            for x in dic_labs.keys():
                print (x, round (min(dic_labs[x]), 1))
            for x in dic_exams.keys():
                print (x, round (max(dic_exams[x]), 1))




