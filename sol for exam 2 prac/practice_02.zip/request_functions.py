import requests

def get_term_data (term):
    form_params = {'term': term}
    response = requests.post('https://thor.cnt.sast.ca/~demo/cmpe2850/SampleRequests.php', data=form_params)
    if response.status_code == 200:
        return response.json()
    else:
        print(f'Failure to get data : {response.status_code}')
        return None